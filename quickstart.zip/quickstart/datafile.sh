#!/bin/bash

./create-csv-file.sh http://localhost:8070 admin admin123 weekly.json
