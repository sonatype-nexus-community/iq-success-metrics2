#!/bin/sh

if [ "$#" -ne 4 ]; then
  echo "usage: ${0} <iq-url> <iq-user> <iq-passwd> <payload-jsonfile>"
  exit -1
fi


iqurl=${1}
iquser=${2}
iqpwd=${3}
payloadfile=${4}

python3 create-success-metrics-csvfile.py ${iqurl} ${iquser} ${iqpwd} ${payloadfile}
python3 create-policy-violations-csvfile.py ${iqurl} ${iquser} ${iqpwd} 
python3 create-application-evaluations-csvfile.py ${iqurl} ${iquser} ${iqpwd} 




