#!/bin/sh

iqurl=${1:-http://localhost:8070}
iquser=${2:-admin}
iqpwd=${3:-admin123}
payloadfile=${4:-weekly.json}

python3 create-success-metrics-csvfile.py ${iqurl} ${iquser} ${iqpwd} ${payloadfile}
python3 create-policy-violations-csvfile.py ${iqurl} ${iquser} ${iqpwd} 
python3 create-application-evaluations-csvfile.py ${iqurl} ${iquser} ${iqpwd} 




