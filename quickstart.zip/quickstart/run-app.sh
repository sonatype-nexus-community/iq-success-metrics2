#!/bin/bash
java -jar success-metrics-3.5.jar
