#!/bin/bash
java -jar success-metrics-1.1.jar
