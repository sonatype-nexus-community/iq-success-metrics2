#!/bin/bash
java -jar success-metrics-3.4.1.jar
