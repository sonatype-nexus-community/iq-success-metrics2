#!/bin/bash
java -jar success-metrics-2.1.2.jar
