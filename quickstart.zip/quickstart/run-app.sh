#!/bin/bash
java -jar success-metrics-1.2.jar
