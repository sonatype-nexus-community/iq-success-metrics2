#!/bin/bash
java -jar success-metrics-3.3.jar
