#!/bin/bash
java -jar success-metrics-1.8.1.jar
