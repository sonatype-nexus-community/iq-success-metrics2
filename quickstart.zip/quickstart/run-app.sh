#!/bin/bash
java -jar success-metrics-3.2.jar
