#!/bin/bash

java -jar successmetrics2.jar
