#!/bin/bash
java -jar success-metrics-3.1.3.jar
