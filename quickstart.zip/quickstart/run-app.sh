#!/bin/bash
java -jar success-metrics-1.6.jar
