#!/bin/bash
java -jar success-metrics-2.0.jar
