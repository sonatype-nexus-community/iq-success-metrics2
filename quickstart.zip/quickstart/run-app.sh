#!/bin/bash
java -jar success-metrics-2.3.jar
