#!/bin/bash
java -jar success-metrics-1.4.jar
