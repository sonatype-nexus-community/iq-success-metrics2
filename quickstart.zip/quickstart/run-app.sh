#!/bin/bash
java -jar success-metrics-2.1.jar
