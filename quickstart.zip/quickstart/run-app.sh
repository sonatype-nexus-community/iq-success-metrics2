#!/bin/bash
java -jar success-metrics-1.9.jar
