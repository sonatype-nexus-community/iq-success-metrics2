#!/bin/bash
java -jar success-metrics-1.5.jar
