#!/bin/bash
java -jar success-metrics-1.7.2.jar
