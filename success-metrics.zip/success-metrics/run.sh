
#!/bin/sh
#Version: 4.4
#Buildtime: 21-10-2020 18:53:36
#Application-name: success-metrics
java -jar success-metrics-4.4.jar
