
#!/bin/sh
#Version: 4.4
#Buildtime: 20-10-2020 18:40:44
#Application-name: success-metrics
java -jar success-metrics-4.4.jar
