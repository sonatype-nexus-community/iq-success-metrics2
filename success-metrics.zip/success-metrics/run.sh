
#!/bin/sh
#Version: 4.5
#Buildtime: 25-10-2020 16:23:00
#Application-name: success-metrics
java -jar success-metrics-4.5.jar
