
#!/bin/sh
#Version: 0.0.1-SNAPSHOT
#Buildtime: 19-10-2020 09:24:40
#Application-name: success-metrics
java -jar success-metrics-0.0.1-SNAPSHOT.jar
