
#!/bin/sh
#Version: 4.3
#Buildtime: 19-10-2020 20:52:58
#Application-name: success-metrics
java -jar success-metrics-4.3.jar
