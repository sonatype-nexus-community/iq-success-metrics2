
#!/bin/sh
#Version: 4.2
#Buildtime: 19-10-2020 20:28:24
#Application-name: success-metrics
java -jar success-metrics-4.2.jar
