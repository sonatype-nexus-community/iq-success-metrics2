
#!/bin/sh
#Version: 4.6
#Buildtime: 30-10-2020 21:01:02
#Application-name: successmetrics
java -jar successmetrics-4.6.jar
